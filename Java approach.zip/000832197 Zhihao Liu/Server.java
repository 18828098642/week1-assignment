

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
//This is the code for UDP server
public class Server {
    public static void main(String[] args) throws IOException {
        int PORTNUM = 1324;//set port number
        DatagramSocket socket = new DatagramSocket(PORTNUM);//create a new socket
        byte[] infoBytes = new byte[1024];
        System.out.println("server is running now");//tell the user the server is ready
        while (true) {
            DatagramPacket receive_packet = new DatagramPacket(infoBytes, infoBytes.length);
            socket.receive(receive_packet);//receive the packet from clients
            String info = new String(infoBytes, 0, receive_packet.getLength());
            int port = receive_packet.getPort();
            InetAddress ip = receive_packet.getAddress();
            System.out.println("Client-" + ip + " port=" + port + ":" + info);//tell the user the information of clients
            byte[] echobuf = info.getBytes();
            DatagramPacket send_packet = new DatagramPacket(echobuf, echobuf.length, ip, port);
            try {
                socket.send(send_packet);//send the packet to client
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
